<?php

namespace Drupal\mymodule\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;


class ImportForm extends ConfigFormBase {

    public function getFormId() {
        return 'my_module_content_import';
    }

    protected function getEditableConfigNames() {
        return [
          'my_module_content_import.settings',
        ];
    }

    public function buildForm(array $form, FormStateInterface $form_state) {
        $config = $this->config('my_module_content_import.settings');

        var_dump("vccvxxcx");
        var_dump("dslds");

        //$types = \Drupal::entityTypeManager()->getStorage('node_type')->loadMultiple();
        //echo "<pre>";
        //print_r($types['product']);
        $content = 'product';
        $fields = get_fields($content);

        var_dump($fields);



        $form['details'] = [
          '#type' => 'details',
          '#title' => $this->t('Details'),
          '#description' => $this->t('Details, #type = details'),
        ];











        


        
        $form['your_message'] = [
          '#type' => 'textfield',
          '#title' => $this->t('Your message'),
          '#default_value' => $config->get('variable_name'),
        ];


        return parent::buildForm($form, $form_state);
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {
        $this->config('my_module_content_import.settings')
          ->set('variable_name', $form_state->getValue('your_message'))
          ->save();
        parent::submitForm($form, $form_state);
    }
}
